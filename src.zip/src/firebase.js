import firebase from "firebase/compat/app";
import "firebase/compat/firestore";
import "firebase/compat/storage";

//your web app ´s firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyCSiKmMPVrd8DNfqDe3TOuzGPd26ot08vY",
  authDomain: "interstellar-app.firebaseapp.com",
  projectId: "interstellar-app",
  storageBucket: "interstellar-app.appspot.com",
  messagingSenderId: "897620471586",
  appId: "1:897620471586:web:c0fa29e378895077c93f7b"
};

// Initialize Firebase
const firebaseApp = firebase.initializeApp(firebaseConfig);
const firestore = firebaseApp.firestore();
const storage = firebase.storage();

export{
storage, firestore as default
} 
